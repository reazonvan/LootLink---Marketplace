# REST API for LootLink

